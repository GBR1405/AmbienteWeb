function openModal(id = '', numMesa = '', estado = '') {
    document.getElementById('modal').classList.add('active');
    document.getElementById('modal-id-mesa').value = id;
    document.getElementById('modal-num-mesa').value = numMesa;
    document.getElementById('modal-estado').value = estado;
    if (id) {
        document.getElementById('modal-title').innerText = 'Editar Mesa';
        document.getElementById('modal-add-btn').style.display = 'none';
        document.getElementById('modal-edit-btn').style.display = 'inline-block';
    } else {
        document.getElementById('modal-title').innerText = 'Agregar Mesa';
        document.getElementById('modal-add-btn').style.display = 'inline-block';
        document.getElementById('modal-edit-btn').style.display = 'none';
    }
}

function closeModal() {
    document.getElementById('modal').classList.remove('active');
}

function openAddModal() {
    document.getElementById('add-modal').classList.add('active');
}

function closeAddModal() {
    document.getElementById('add-modal').classList.remove('active');
}

function openEditModal(id, numMesa, estado) {
    document.getElementById('edit-modal').classList.add('active');
    document.getElementById('edit-id-mesa').value = id;
    document.getElementById('edit-num-mesa').value = numMesa;
    document.getElementById('edit-estado').value = estado;
}

function closeEditModal() {
    document.getElementById('edit-modal').classList.remove('active');
}


